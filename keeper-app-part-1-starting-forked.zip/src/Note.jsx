import React from "react";

function Notes()
{
  return (
    <div> 
      <h1 className = ".note h1" contentEditable = "true"> Note's Heading </h1>
      <p className = ".note p" contentEditable = "true"> Type your text here </p>
    </div>
  );
}

export default Notes;